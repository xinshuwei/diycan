function varargout = CANET(varargin)
% CANET M-file for CANET.fig
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help CANET

% Last Modified by GUIDE v2.5 13-Dec-2014 16:28:52

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @CANET_OpeningFcn, ...
                   'gui_OutputFcn',  @CANET_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before CANET is made visible.
function CANET_OpeningFcn(hObject, eventdata, handles, varargin)
global DEVICETYPE;
global DEVICEINDEX;
global CANINDEX;
global CONNECTED;
global LISTBOXNUM;
global WORKSTYLE;
LISTBOXNUM = 0;
CONNECTED=0;
DEVICETYPE=17;
DEVICEINDEX=0;
CANINDEX=0;
WORKSTYLE=0;
set(handles.edit_NativePort,'Enable','off');

% Choose default command line output for CANET
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes CANET wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = CANET_OutputFcn(hObject, eventdata, handles) 
% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton_Connect.
function pushbutton_Connect_Callback(hObject, eventdata, handles)
global DEVICETYPE;
global DEVICEINDEX;
global CONNECTED;
global WORKSTYLE;
DEVICEINDEX = get(handles.popupmenu_DeviceIndex,'value')-1;
if CONNECTED~=1
   if WORKSTYLE~=2
       Reserve=0;
       DEVICETYPE=17;
   else
       Reserve=str2num(get(handles.edit_NativePort,'String'));
       DEVICETYPE=12;
   end
    if VCI_OpenDevice(DEVICETYPE,DEVICEINDEX,Reserve)
        ID1 = str2num(get(handles.edit_ID1,'String'));
        ID2 = str2num(get(handles.edit_ID2,'String'));
        ID3 = str2num(get(handles.edit_ID3,'String'));
        ID4 = str2num(get(handles.edit_ID4,'String'));
        if WORKSTYLE ==0
            if VCI_SetReference5(DEVICETYPE,DEVICEINDEX,0,0,ID1,ID2,ID3,ID4)~=1
                msgbox('����Ŀ���ַʧ��!');
            end
            Port = str2num(get(handles.edit_Port,'String'));
            if VCI_SetReference6(DEVICETYPE,DEVICEINDEX,0,1,Port)~=1
               msgbox('���ö˿�ʧ�ܣ�');
            end
        elseif WORKSTYLE ==1
            if VCI_SetReference8(DEVICETYPE,DEVICEINDEX,0,4,1)~=1
                msgbox('���ù���ģʽʧ��!');
            end
            NativePort = str2num(get(handles.edit_NativePort,'String'));
            if VCI_SetReference7(DEVICETYPE,DEVICEINDEX,0,2,NativePort)~=1
                msgbox('���ñ����˿�ʧ��!');
            end
        else
            %CANET UDP ��ʽ
            if VCI_SetReference5(DEVICETYPE,DEVICEINDEX,0,0,ID1,ID2,ID3,ID4)~=1
                msgbox('����Ŀ���ַʧ��!');
            end
            Port = str2num(get(handles.edit_Port,'String'));
            if VCI_SetReference6(DEVICETYPE,DEVICEINDEX,0,1,Port)~=1
               msgbox('���ö˿�ʧ�ܣ�');
            end
        end
        if VCI_StartCAN(DEVICETYPE,DEVICEINDEX,0)
            CONNECTED =1;
            set(hObject,'String','�Ͽ�');
             t = timer('TimerFcn',{@timerCallback,handles.listbox_Information}, 'ExecutionMode', 'fixedDelay', 'Period', 0.5);
    start(t);
        else
            msgbox('Start CANʧ��!');
        end
    else
        msgbox('���豸ʧ�ܣ�');
    end
else
    if VCI_CloseDevice(DEVICETYPE,DEVICEINDEX)~= 1
        msgbox('�ر�CANʧ�ܣ�');
    else
        CONNECTED=0;
        set(hObject,'String','����');
    end
end

% --- Executes on button press in pushbutton_Send.
function pushbutton_Send_Callback(hObject, eventdata, handles)
global DEVICETYPE;
global DEVICEINDEX;
global CANINDEX;
global LISTBOXNUM;
global WORKSTYLE;
if WORKSTYLE~=2
       DEVICETYPE=17;
else
       DEVICETYPE=12;
end
ID=hex2dec(get(handles.edit_FrameID,'String'));
TimeStamp=0;
TimeFlag=0;
%SendType=get(handles.popupmenu_SendType,'value')-1;
SendType = 0;
RemoteFlag=get(handles.popupmenu3,'value')-1;
ExternFlag=get(handles.popupmenu2,'value')-1;
DataLen=8;
SendNums=str2double(get(handles.edit_SendNums,'String'));%����֡��
Data1=hex2dec(get(handles.edit_Data1,'String'));
Data2=hex2dec(get(handles.edit_Data2,'String'));
Data3=hex2dec(get(handles.edit_Data3,'String'));
Data4=hex2dec(get(handles.edit_Data4,'String'));
Data5=hex2dec(get(handles.edit_Data5,'String'));
Data6=hex2dec(get(handles.edit_Data6,'String'));
Data7=hex2dec(get(handles.edit_Data7,'String'));
Data8=hex2dec(get(handles.edit_Data8,'String'));
Data=[Data1 Data2 Data3 Data4 Data5 Data6 Data7 Data8];
Reserved=[0 0 0];
Frame=[ID TimeStamp TimeFlag SendType RemoteFlag ExternFlag DataLen Data Reserved];
Frames=Frame;
for i=1:SendNums-1
    Frames=[Frames;Frame];
end
Succeed = VCI_Transmit(DEVICETYPE,DEVICEINDEX,CANINDEX, Frames,SendNums);%���ͳɹ���֡��
if Succeed
for i=1:Succeed
    ID=Frames(i,1);
    strID=strcat('ID��',sprintf('%08x',ID));
    
    TimeStamp=Frames(i,2);
    strTimeStamp=strcat('       ʱ���ʶ��',sprintf('%08x',TimeStamp));
    
    strDir='       ����';
        
    RemoteFlag = Frames(i,4);
    if RemoteFlag
        strRemoteFlag = '      Զ��֡';
    else
        strRemoteFlag = '      ����֡';
    end 
    
    ExternFlag = Frames(i,5);
    if ExternFlag
        strExternFlag = '      ��չ֡';
    else
        strExternFlag = '      ��׼֡';
    end
    
    DataLen = Frames(i,7);
    strDataLen = strcat('       ���ȣ�',num2str(DataLen));
    strData='';
    data1=num2str(dec2hex(Frames(i,8)));
    data2=num2str(dec2hex(Frames(i,9)));
    data3=num2str(dec2hex(Frames(i,10)));
    data4=num2str(dec2hex(Frames(i,11)));
    data5=num2str(dec2hex(Frames(i,12)));
    data6=num2str(dec2hex(Frames(i,13)));
    data7=num2str(dec2hex(Frames(i,14)));
    data8=num2str(dec2hex(Frames(i,15)));
    strData=strcat(data1,' -',data2,' -',data3,' -',data4,' -',data5,' -',data6,' -',data7,' -',data8);
    strr=get(handles.listbox_Information,'String');
    strr{i+LISTBOXNUM}=strcat(strID,strTimeStamp,strDir,strRemoteFlag,strExternFlag,strDataLen,'           Data��',strData);
    set(handles.listbox_Information,'String',strr);
end
LISTBOXNUM = LISTBOXNUM + Succeed;%listbox���֡���ӽ��ճɹ���֡
else
    %ע�⣺���û�ж��������������ô˺�������ȡ����ǰ�Ĵ����룬
    %ǧ����ʡ����һ������ʹ����ܲ���֪����������ʲô��
	[one,two] = VCI_ReadErrInfo(DEVICETYPE,DEVICEINDEX,CANINDEX);
    msgbox('��������ʧ��');
end



% --- Executes on button press in pushbutton_Clear.
function pushbutton_Clear_Callback(hObject, eventdata, handles)
global DEVICETYPE;
global DEVICEINDEX;
global CANINDEX;
global LISTBOXNUM;
VCI_ClearBuffer(DEVICETYPE, DEVICEINDEX, CANINDEX);
LISTBOXNUM = 0;
strr='';
set(handles.listbox_Information,'String',strr);




% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
global DEVICETYPE;
global DEVICEINDEX;
global CONNECTED;
if CONNECTED
    if VCI_CloseDevice(DEVICETYPE,DEVICEINDEX)~= 1
    msgbox('�ر�CANʧ�ܣ�');
    end
end
delete(hObject);

function timerCallback(obj, event,listbox_Information,edit_Timeout)
global CONNECTED;
global DEVICETYPE;
global DEVICEINDEX;
global CANINDEX;
global LISTBOXNUM;
global WORKSTYLE;
if WORKSTYLE~=2
       DEVICETYPE=17;
else
       DEVICETYPE=12;
 end
ID=0;
TimeStamp=0;
TimeFlag=0;
SendType=0;
RemoteFlag=0;
ExternFlag=0;
DataLen=8;
if CONNECTED~=1
    stop(obj);
    delete(obj);
    clear obj;
else
    len = VCI_GetReceiveNum(DEVICETYPE,DEVICEINDEX,CANINDEX);
    if len
         [GetLength,Frames]=VCI_Receive(DEVICETYPE,DEVICEINDEX,CANINDEX,50,400);
         if GetLength
             for i=1:GetLength
                 ID=Frames(i,1);
                 strID=strcat('ID��',sprintf('%08x',ID));
                 TimeStamp=Frames(i,2);
                 strTimeStamp=strcat('       ʱ���ʶ��',num2str(TimeStamp));
    
                 strDir='       ����';
        
                 RemoteFlag = Frames(i,4);
                 if RemoteFlag
                     strRemoteFlag = '      Զ��֡';
                 else
                     strRemoteFlag = '      ����֡';
                 end

                 ExternFlag = Frames(i,5);
                 if ExternFlag
                     strExternFlag = '      ��չ֡';
                 else
                     strExternFlag = '      ��׼֡';
                 end
                 
                 DataLen = Frames(i,7);
                 strDataLen = strcat('       ���ȣ�',num2str(DataLen));
                 strData='';
                 data1=num2str(dec2hex(Frames(i,8)));
                 data2=num2str(dec2hex(Frames(i,9)));
                 data3=num2str(dec2hex(Frames(i,10)));
                 data4=num2str(dec2hex(Frames(i,11)));
                 data5=num2str(dec2hex(Frames(i,12)));
                 data6=num2str(dec2hex(Frames(i,13)));
                 data7=num2str(dec2hex(Frames(i,14)));
                 data8=num2str(dec2hex(Frames(i,15)));
                 
                 strData=strcat(data1,' -',data2,' -',data3,' -',data4,' -',data5,' -',data6,' -',data7,' -',data8);
                 strr=get(listbox_Information,'String');

                 strr{i+LISTBOXNUM}=strcat(strID,strTimeStamp,strDir,strRemoteFlag,strExternFlag,strDataLen,'           Data��',strData);
                 set(listbox_Information,'String',strr);
             end
              LISTBOXNUM = LISTBOXNUM + GetLength;%listbox���֡����1
         end
    else
        
    end
end





% --- Executes on selection change in popupmenu_DeviceIndex.
function popupmenu_DeviceIndex_Callback(hObject, eventdata, handles)
global DEVICEINDEX;
DEVICEINDEX=get(handles.popupmenu_DeviceIndex,'value')-1;





% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
global FRAMETYPE;
select=get(hObject,'value');
switch select
    case 1
       FRAMETYPE=0;
    case 2
       FRAMETYPE=1;
end





% --- Executes on selection change in popupmenu3.
function popupmenu3_Callback(hObject, eventdata, handles)
global FRAMEFORMAT;
select=get(hObject,'value');
switch select
    case 1
       FRAMEFORMAT=0;
    case 2
       FRAMEFORMAT=1;
end






% --- Executes on selection change in popupmenu_WorkStyle.
function popupmenu_WorkStyle_Callback(hObject, eventdata, handles)
global WORKSTYLE;
WORKSTYLE=get(handles.popupmenu_WorkStyle,'value')-1;
if WORKSTYLE ==0
    set(handles.edit_NativePort,'Enable','on');
    set(handles.edit_ID1,'Enable','off');
    set(handles.edit_ID2,'Enable','off');
    set(handles.edit_ID3,'Enable','off');
    set(handles.edit_ID4,'Enable','off');
    set(handles.edit_Port,'Enable','off');
elseif WORKSTYLE ==1
    set(handles.edit_NativePort,'Enable','off');
    set(handles.edit_ID1,'Enable','on');
    set(handles.edit_ID2,'Enable','on');
    set(handles.edit_ID3,'Enable','on');
    set(handles.edit_ID4,'Enable','on');
    set(handles.edit_Port,'Enable','on');
else
    set(handles.edit_NativePort,'Enable','on');
    set(handles.edit_ID1,'Enable','on');
    set(handles.edit_ID2,'Enable','on');
    set(handles.edit_ID3,'Enable','on');
    set(handles.edit_ID4,'Enable','on');
    set(handles.edit_Port,'Enable','on');
end

